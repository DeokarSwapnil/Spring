
import java.util.LinkedHashMap;

public class LinkedMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashMap<Integer,String> hs = new LinkedHashMap<>();
		hs.put(01,"abc");
		hs.put(02,"xyz");
		hs.put(03,"pqr");
		 //hs.remove(01,"abc");
		//System.out.println(hs);
		
		

//       lhm.remove(160);
//     
//      
//      
      System.out.println(hs.keySet());
//       System.out.println(lhm.values());
//      
//       for(Integer k : lhm.keySet()){
//           System.out.println("Key :" +k);
//       }
//       for(String v : lhm.values()){
//           System.out.println("Values :" +v);
//       }
//       for(Map.Entry me : lhm.entrySet()){
//           System.out.println(me.getKey() +" : "+me.getValue());
//       }
		
	}

}
