import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
 
public class Abc {
 
    ArrayList<String> BookName = new ArrayList<String>();
    ArrayList<String> authorname = new ArrayList<String>();
    ArrayList<Integer> price = new ArrayList<Integer>();
    ArrayList<Integer> id = new ArrayList<Integer>();
 
    public void W() {
        int id[] = {01,02};
        String BookName[] = {"the warriors", "junglee book"};
        String authorname[] = {"hekunshi", "sizuka"};
        int price[] = {78,89};
        
 
        try {
            FileWriter fw = new FileWriter("C:\\Users\\swapnil_deokar\\Desktop\\Hello.txt");
            for (int i = 0; i < id.length; i++) {
                String DATA = id[i] + "&" + BookName[i] + "&"+authorname[i] + "&"+price[i]+"&";
                fw.write(DATA);
            }
            fw.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("Success...");
    }
 
    public void R() {
        String RAWDATA = "";
        try {
            FileReader fr = new FileReader("C:\\Users\\swapnil_deokar\\Desktop\\Hello.txt");
            int ca;
            while ((ca = fr.read()) != -1) {
                char ch = (char) ca;
                RAWDATA = RAWDATA + ch;
            }
            fr.close();
            String RAW[] = RAWDATA.split("&");
            System.out.println();
 
            for (int i = 0; i < RAW.length; i = i + 4) {
                
                id.add(Integer.parseInt(RAW[i]));
                BookName.add(RAW[i+1]);
                authorname.add(RAW[i+2]);
                price.add(Integer.parseInt(RAW[i + 3]));
                
            }
        } catch (Exception e) {
            System.out.println("No File Exist");
        }

    }
 
    public void PrintData() {
    	 for(int i=0;i<id.size(); i++) {
    	        System.out.println(id.get(i)+" "+ BookName.get(i) + " " + authorname.get(i) +" "+ price.get(i) + " ");
    	        }
       /* id.forEach(System.out::println);
        BookName.forEach(System.out::println);
        authorname.forEach(System.out::println);
        price.forEach(System.out::println);*/
    }
 
    public static void main(String[] args) {
        Abc m = new Abc();
        System.out.println("----------------------------------------");
        m.W();
        System.out.println("----------------------------------------");
        m.R();
        System.out.println("----------------------------------------");
        m.PrintData();
 
    }
}