
public class Generics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		class Test<I,T>{

		    private I objI;
		    private T objT;

		    public void add(I i,T t){
		        this.objI = i;
		        this.objT = t;

		    }
		    public I getI(){
		        return this.objI;
		    }
		    public T getT(){
		        return this.objT;
		    }

		    public String get(){
		        return "["+objI + " : "+objT+"]";
		    }

		}

	}

}
