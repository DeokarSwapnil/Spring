import java.util.HashMap;
import java.util.Map;

public class Hash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> hs = new HashMap<>();
		
		hs.put(01,"abc");
		hs.put(02,"xyz");
		hs.put(03,"pqr");
		//for(Map.Entry hi : hs.entrySet()) {
		//	System.out.println(hi.getKey() + " : "+hi.getValue());
		//}
		//hs.remove(02,"xyz");//remove the data
		/*hs.replace(03,"hello" ); replace the data*/
		/*hs.replaceAll((K,V)-> "null"); replace all*/
		System.out.println(hs);

	}

}
