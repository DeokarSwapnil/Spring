import java.util.Scanner;
 

class Book {
    int bookID;
    String name;
    String author;
    char avail;
    int yearOfPublish;
 

    Book(int bookID, String name, String author, char avail, int yearOfPublish) {
        this.bookID = bookID;
        this.name = name;
        this.author = author;
        this.avail = avail;
        this.yearOfPublish = yearOfPublish;
    }
 

    void print(){
        System.out.println(bookID +"\t" + name + "\t" + author    + "\t" + avail + "\t" + yearOfPublish);
    }
}
 

class Issue {
    String name;
    String address;
    Long cnumber;
    String idate;
    String rdate;
    int id;
 

    Issue(String name, String address, Long cnumber,String idate, String rdate, int id) {
        this.name = name;
        this.address = address;
        this.cnumber = cnumber;
        this.idate = idate;
        this.rdate = rdate;
        this.id = id;        
    }
    void print() {
        System.out.println(name + "\t" + address + "\t" + cnumber + "\t" + idate + "\t" + rdate + "\t" + id);
    }
}
 

class Library {
    Book[] book = new Book[100];
    int librarysize = 0;
    Issue[] issuedBook = new Issue[100];
    int issuesize = 0;
    Scanner sc = new Scanner(System.in);
 

    void insert(int id, String bname, String aname, int pyear){
        Book b = new Book(id,bname,aname,'A',pyear);
        book[librarysize++] = b;
    }
 

    void printBooks(){
        System.out.println("Book ID\tBook Name\tAuthor\tAvailability\tPublish Year");
        for(int i=0 ; i<librarysize ; i++) {
            book[i].print();
        }
        }
 

    void printIssuedBook() {
        System.out.println("Issuer Name\tAddess\tContact Number\tIssue Date\tReturnDate\tBookID");
        for (int i = 0; i<issuesize ; i++ ) {
            issuedBook[i].print();
        }
    }
 

    void printAuthors() {
        for(int i=0 ; i<librarysize ; i++) {
            System.out.println(book[i].author);
        }
    }
 

    void search() {
        System.out.println("1. Search by ID");
        System.out.println("2. Search by name");
        System.out.println("3. Search by author");
        int searchChoice = sc.nextInt();    
        if (searchChoice == 1) {
            System.out.println("Enter the ID");
            int id = sc.nextInt();
            for (int i = 0; i<librarysize ; i++ ) {
                if(id == book[i].bookID)
                    book[i].print();
            }
        }
        else if (searchChoice == 2) {
            System.out.println("Enter the name");
            String bookName = sc.next();
            for (int i = 0; i<librarysize ; i++ ) {
                if(bookName.equalsIgnoreCase(book[i].name))
                    book[i].print();
            }   
        }
        else if (searchChoice == 3) {
            System.out.println("Enter the Author name");
            String auth = sc.next();
            for (int i = 0; i<librarysize ; i++ ) {
                if(auth.equalsIgnoreCase(book[i].author))
                    book[i].print();
            }
        }
    }
 

    void issueBook(String name, String add,Long number,String idate, String rdate, int id) {
        Issue iss = new Issue(name,add,number,idate,rdate,id);
        issuedBook[issuesize++] = iss;
        for (int i = 0 ; i<librarysize ; i++) {
            if(id == book[i].bookID)
                book[i].avail = 'N';
        }
    }
 

    void menu(){
        System.out.println();
        System.out.println();
        System.out.println("Welcome to the Library");
        System.out.println();
        System.out.println("1. Insert Book");
        System.out.println("2. List down all the books");
        System.out.println("3. List down all the authors");
        System.out.println("4. Seaching book");
        System.out.println("5. issue the Book");
        System.out.println("6. issued Books");
        System.out.println("0. exit");
    }
}
 

class LibraryApp{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Library lib = new Library();
        while(true) {
            lib.menu();
            int choice = sc.nextInt();
 

            switch(choice) {
                case 1: System.out.println("Enter ID");
                        int id = sc.nextInt();
                        System.out.println("Enter Book Name");
                        String bname = sc.next();
                        System.out.println("Enter Author Name");
                        String aname = sc.next();
                        System.out.println("Enter Publish Year");
                        int pyear = sc.nextInt();
                        lib.insert(id, bname, aname, pyear);
                        break;
                case 2: System.out.println("The Books are");
                        lib.printBooks();
                        break;
                case 3:    System.out.println("The Authors are");
                        lib.printAuthors();
                        break;
                case 4:    lib.search();
                        break;
                case 5:    System.out.println("Enter your name");
                        String name = sc.next();
                        System.out.println("Enter your address");
                        String add = sc.next();
                        System.out.println("Enter your contact number");
                        Long number = sc.nextLong();
                        System.out.println("Enter your issue date(dd/mm/yyyy)");
                        String idate = sc.next();
                        System.out.println("Enter your return date(dd/mm/yyyy)");
                        String rdate = sc.next();
                        System.out.println("Enter your Book ID");
                        int bid = sc.nextInt();
                        lib.issueBook(name,add,number,idate,rdate,bid);
                        break;
                case 6:    lib.printIssuedBook();
                        break;
                case 0:    System.exit(0);
                default: System.out.println("Invalid choice!!!");
            }
        }
 

    }
}