import java.util.TreeMap;

public class TreeHasmp {
	public static void main(String[] args) {
		TreeMap<Integer, String> tm=new TreeMap<>();

        tm.put(26, "26");
        tm.put(5, "05");
        tm.put(100, "100");
        tm.put(1, "1");
        tm.put(60, "60");

        System.out.println(tm);
        System.out.println(tm.descendingMap());
        System.out.println(tm.headMap(26,true));//false
        System.out.println(tm.tailMap(26,false));//true
        System.out.println(tm.subMap(5,60));// true   false
	}

}
