package com.demo;

import org.springframework.stereotype.Component;

@Component
public class Tyre {

}
