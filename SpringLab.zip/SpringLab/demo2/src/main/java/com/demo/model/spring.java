package com.demo.model;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.demo.Bike;
import com.demo.Engine;
import com.demo.car;




@Configuration
@ComponentScan(basePackages = "com.demo")
public class spring {
	
	@Bean
    public Engine getEngine() {
		return new Engine("3000 CC");
	
	
	

}
}
