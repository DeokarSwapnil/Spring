package com.demo;

import org.springframework.stereotype.Component;

public class AmdProcesssor {
	
	@Component("amd")
	public class AmdProcessor implements Processor {

		@Override
		public void doProcessing() {
			System.out.println("AMD processor is running");
			
		}

}
}
