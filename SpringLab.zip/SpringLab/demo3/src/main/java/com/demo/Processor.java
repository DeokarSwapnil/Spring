package com.demo;

public interface Processor {

	void doProcessing();

}
