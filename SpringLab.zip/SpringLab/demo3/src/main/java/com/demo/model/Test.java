package com.demo.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;



import com.demo.Laptop;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// IoC Container or Spring Container
		ApplicationContext context = new AnnotationConfigApplicationContext(spring.class);
			
			
		Laptop laptop = context.getBean("laptop", Laptop.class);
		laptop.boot();
	}

}
