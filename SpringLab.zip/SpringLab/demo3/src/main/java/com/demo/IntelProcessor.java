package com.demo;

import org.springframework.stereotype.Component;

public class IntelProcessor {

	@Component("intel")
	//@Primary
	public class intelProcessor implements Processor {

		@Override
		public void doProcessing() {
			System.out.println("Intel i9 processor is running");
			
		}

	}
}
